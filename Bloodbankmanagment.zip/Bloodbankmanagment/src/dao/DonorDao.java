/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.ConnectionProvider;
import java.sql.*;
import java.util.Map;

public class DonorDao {

    // 🆕 Add Donor
    public static boolean addDonor(Map<String, String> donorData) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement(
                "INSERT INTO donor1(donorId, fullName, fatherName, motherName, DOB, mobileNo, gender, email, bloodGroup, city, address) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)"
            );
            ps.setString(1, donorData.get("donorId"));
            ps.setString(2, donorData.get("fullName"));
            ps.setString(3, donorData.get("fatherName"));
            ps.setString(4, donorData.get("motherName"));
            ps.setString(5, donorData.get("DOB"));
            ps.setString(6, donorData.get("mobileNo"));
            ps.setString(7, donorData.get("gender"));
            ps.setString(8, donorData.get("email"));
            ps.setString(9, donorData.get("bloodGroup"));
            ps.setString(10, donorData.get("city"));
            ps.setString(11, donorData.get("address"));

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 🆕 Get all donors (ResultSet)
    public static ResultSet getAllDonors() {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM donor1");
            return ps.executeQuery();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // 🆕 Update Donor by id
    public static boolean updateDonor(int id, Map<String, String> donorData) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement(
                "UPDATE donor1 SET donorId=?, fullName=?, fatherName=?, motherName=?, DOB=?, mobileNo=?, gender=?, email=?, bloodGroup=?, city=?, address=? WHERE id=?"
            );
            ps.setString(1, donorData.get("donorId"));
            ps.setString(2, donorData.get("fullName"));
            ps.setString(3, donorData.get("fatherName"));
            ps.setString(4, donorData.get("motherName"));
            ps.setString(5, donorData.get("DOB"));
            ps.setString(6, donorData.get("mobileNo"));
            ps.setString(7, donorData.get("gender"));
            ps.setString(8, donorData.get("email"));
            ps.setString(9, donorData.get("bloodGroup"));
            ps.setString(10, donorData.get("city"));
            ps.setString(11, donorData.get("address"));
            ps.setInt(12, id);

            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 🆕 Delete Donor by donorId
    public static boolean deleteDonor(int donorId) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("DELETE FROM donor1 WHERE donorId = ?");
            ps.setInt(1, donorId);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 💡 New method: get all donor details as a formatted String for printing
    public static String getAllDonorsString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-5s %-20s %-12s %-10s %-10s %-8s %-10s%n",
                "ID", "Name", "Mobile", "BloodGrp", "City", "Gender", "Email"));
        sb.append("=".repeat(80)).append("\n");

        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM donor1");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                sb.append(String.format(
                        "%-5d %-20s %-12s %-10s %-10s %-8s %-10s%n",
                        rs.getInt("id"),
                        rs.getString("fullName"),
                        rs.getString("mobileNo"),
                        rs.getString("bloodGroup"),
                        rs.getString("city"),
                        rs.getString("gender"),
                        rs.getString("email")
                ));
            }

        } catch (Exception e) {
            e.printStackTrace();
            sb.append("Error fetching donors: ").append(e.getMessage()).append("\n");
        }

        return sb.toString();
    }
}

