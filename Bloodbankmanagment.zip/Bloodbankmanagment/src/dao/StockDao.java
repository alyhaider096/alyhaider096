/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.ConnectionProvider;
import java.sql.*;

public class StockDao {

    // Increase stock by units
    public static boolean increaseStock(String bloodGroup, int units) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement(
                "UPDATE stock1 SET units = units + ? WHERE bloodGroup = ?"
            );
            ps.setInt(1, units);
            ps.setString(2, bloodGroup);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Decrease stock by units if enough units exist
    public static boolean decreaseStock(String bloodGroup, int units) {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement(
                "UPDATE stock1 SET units = units - ? WHERE bloodGroup = ? AND units >= ?"
            );
            ps.setInt(1, units);
            ps.setString(2, bloodGroup);
            ps.setInt(3, units);
            return ps.executeUpdate() > 0;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Get ResultSet for stock details (existing)
    public static ResultSet getStockDetails() throws SQLException {
        Connection con = ConnectionProvider.getCon();
        PreparedStatement ps = con.prepareStatement("SELECT * FROM stock1");
        return ps.executeQuery();
    }

    // 💡 New: return formatted stock data for display or print
    public static String getStockDetailsString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-12s %-8s%n", "BloodGroup", "Units"));
        sb.append("=".repeat(25)).append("\n");

        try (Connection con = ConnectionProvider.getCon();
             PreparedStatement ps = con.prepareStatement("SELECT * FROM stock1");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                sb.append(String.format("%-12s %-8d%n",
                        rs.getString("bloodGroup"),
                        rs.getInt("units")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
            sb.append("Error fetching stock: ").append(e.getMessage()).append("\n");
        }

        return sb.toString();
    }
}
