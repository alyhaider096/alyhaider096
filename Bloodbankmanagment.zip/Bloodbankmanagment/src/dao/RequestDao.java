/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package dao;

import db.ConnectionProvider;
import java.sql.*;
import java.util.Map;

public class RequestDao {

    // 💾 Save a new blood request (existing)
    public static boolean saveRequest(String name, String bloodGroup, int units, String hospital, String doctor, String contact) {
        try {
            Connection con = ConnectionProvider.getCon();
            String sql = "INSERT INTO bloodrequest (patientName, bloodGroup, unitsRequired, hospital, doctorName, contactNumber, status) VALUES (?, ?, ?, ?, ?, ?, 'Pending')";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, name);
            ps.setString(2, bloodGroup);
            ps.setInt(3, units);
            ps.setString(4, hospital);
            ps.setString(5, doctor);
            ps.setString(6, contact);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // 🆕 New: Fetch all requests as formatted string for display/print
    public static String getAllRequestsString() {
        StringBuilder sb = new StringBuilder();
        sb.append(String.format("%-5s %-20s %-12s %-10s %-10s %-10s%n",
                "ID", "Patient", "BloodGrp", "Units", "Hospital", "Status"));
        sb.append("=".repeat(70)).append("\n");

        try (Connection con = ConnectionProvider.getCon();
             // Adjust table/column names if different
             PreparedStatement ps = con.prepareStatement("SELECT id, patientName, bloodGroup, unitsRequired, hospital, status FROM bloodrequest");
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                sb.append(String.format("%-5d %-20s %-12s %-10d %-10s %-10s%n",
                        rs.getInt("requestid"),
                        rs.getString("patientName"),
                        rs.getString("bloodGroup"),
                        rs.getInt("unitsRequired"),
                        rs.getString("hospital"),
                        rs.getString("status")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
            sb.append("Error fetching requests: ").append(e.getMessage()).append("\n");
        }

        return sb.toString();
    }

   public static ResultSet getAllRequests() {
    try {
        Connection con = ConnectionProvider.getCon();
        PreparedStatement ps = con.prepareStatement(
            "SELECT requestid, patientName, bloodGroup, unitsRequired, hospital, status FROM bloodrequest"
        );
        return ps.executeQuery();
    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}

}

