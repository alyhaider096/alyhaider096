/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package gui;

import dao.DonorDao;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.net.URL;
import java.sql.ResultSet;

public class AllDonorDetail extends JFrame {

    JTable donorTable;
    DefaultTableModel tableModel;

    public AllDonorDetail() {
        setTitle("All Donor Details");
        setSize(700, 500);
        setLocation(360, 130);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        // Background image
        URL imageUrl = getClass().getResource("/resources/images/all page background image.png");
        if (imageUrl != null) {
            setContentPane(new JLabel(new ImageIcon(imageUrl)));
        } else {
            System.out.println("AllDonorDetail background image not found!");
        }

        // Title
        JLabel title = new JLabel("All Donor Details");
        title.setFont(new Font("Arial", Font.BOLD, 32));
        title.setBounds(220, 20, 400, 40);
        add(title);

        // Table column headers
        String[] columns = {
            "donorId", "fullName", "fatherName", "motherName",
            "DOB", "mobileNo", "gender", "email", "bloodGroup", "city", "address"
        };

        // Initialize table
        tableModel = new DefaultTableModel(columns, 0);
        donorTable = new JTable(tableModel);

        // Scroll pane for table
        JScrollPane scrollPane = new JScrollPane(donorTable);
        scrollPane.setBounds(20, 80, 650, 320);
        add(scrollPane);

        // Load data from DB
        try {
            ResultSet rs = DonorDao.getAllDonors();
            while (rs.next()) {
                Object[] row = new Object[11];
                row[0] = rs.getInt("donorId");
                row[1] = rs.getString("fullName");
                row[2] = rs.getString("fatherName");
                row[3] = rs.getString("motherName");
                row[4] = rs.getString("DOB");
                row[5] = rs.getString("mobileNo");
                row[6] = rs.getString("gender");
                row[7] = rs.getString("email");
                row[8] = rs.getString("bloodGroup");
                row[9] = rs.getString("city");
                row[10] = rs.getString("address");

                tableModel.addRow(row);
            }
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error fetching donor data from database.");
        }

        // Close Button
        JButton btnClose = new JButton("Close");
        btnClose.setBounds(300, 420, 100, 30);
        add(btnClose);

        btnClose.addActionListener(e -> dispose());

        setVisible(true);
    }

    public static void main(String[] args) {
        new AllDonorDetail();
    }
}
