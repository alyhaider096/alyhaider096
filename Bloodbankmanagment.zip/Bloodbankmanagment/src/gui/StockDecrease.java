/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import dao.StockDao;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.net.URL;
import java.sql.ResultSet;

public class StockDecrease extends JFrame {

    public JComboBox<String> bloodGroupCombo;
    public JTextField unitField;
    public JTable table;
    public JButton btnUpdate, btnClose;

    public StockDecrease() {
        setTitle("Stock Decrease");
        setSize(700, 500);
        setLocation(360, 130);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Background
        URL bgUrl = getClass().getResource("/resources/images/all page background image.png");
        if (bgUrl != null) {
            setContentPane(new JLabel(new ImageIcon(bgUrl)));
        }

        JLabel title = new JLabel("Stock Decrease");
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setBounds(200, 10, 300, 40);
        add(title);

        JSeparator sep1 = new JSeparator();
        sep1.setBounds(10, 60, 670, 10);
        add(sep1);

        JLabel lblBloodGroup = new JLabel("Blood Group:");
        lblBloodGroup.setFont(new Font("Arial", Font.PLAIN, 16));
        lblBloodGroup.setBounds(30, 70, 120, 25);
        add(lblBloodGroup);

        bloodGroupCombo = new JComboBox<>(new String[]{
                "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"
        });
        bloodGroupCombo.setBounds(150, 70, 120, 25);
        add(bloodGroupCombo);

        JLabel lblUnits = new JLabel("Units:");
        lblUnits.setFont(new Font("Arial", Font.PLAIN, 16));
        lblUnits.setBounds(300, 70, 50, 25);
        add(lblUnits);

        unitField = new JTextField();
        unitField.setBounds(360, 70, 100, 25);
        add(unitField);

        btnUpdate = new JButton("Update");
        btnUpdate.setBounds(480, 70, 100, 25);
        add(btnUpdate);

        JSeparator sep2 = new JSeparator();
        sep2.setBounds(10, 110, 670, 10);
        add(sep2);

        table = new JTable(new DefaultTableModel(
                new Object[][]{},
                new String[]{"Blood Group", "Units"}
        ));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 130, 640, 250);
        add(scrollPane);

        btnClose = new JButton("Close");
        btnClose.setBounds(290, 400, 100, 30);
        add(btnClose);
        btnClose.addActionListener(e -> dispose());

        // Load table initially
        loadTableData();

        // Update button logic
        btnUpdate.addActionListener(e -> {
            String bloodGroup = bloodGroupCombo.getSelectedItem().toString();
            String unitText = unitField.getText().trim();

            if (unitText.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter number of units.");
                return;
            }

            try {
                int units = Integer.parseInt(unitText);

                if (units <= 0) {
                    JOptionPane.showMessageDialog(this, "Units must be positive.");
                    return;
                }

                boolean success = StockDao.decreaseStock(bloodGroup, units);
                if (success) {
                    JOptionPane.showMessageDialog(this, "Stock decreased successfully.");
                    unitField.setText("");
                    loadTableData(); // refresh
                } else {
                    JOptionPane.showMessageDialog(this, "Failed to decrease stock. Not enough units available.");
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Invalid number format for units.");
            }
        });

        setVisible(true);
    }

    private void loadTableData() {
        try {
            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setRowCount(0); // clear existing

            ResultSet rs = StockDao.getStockDetails();
            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getString("bloodGroup"),
                        rs.getInt("units")
                });
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading stock data.");
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new StockDecrease();
    }
}
