/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;
import dao.StockDao;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.net.URL;

public class StockDetail extends JFrame {

    public JTable table;
    public JButton btnClose;

    public StockDetail() {
        setTitle("Stock Details");
        setSize(700, 500);
        setLocation(360, 130);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Background
        URL bgUrl = getClass().getResource("/resources/images/all page background image.png");
        if (bgUrl != null) {
            setContentPane(new JLabel(new ImageIcon(bgUrl)));
        }

        JLabel title = new JLabel("Stock Details");
        title.setFont(new Font("Arial", Font.BOLD, 28));
        title.setBounds(220, 10, 300, 40);
        add(title);

        JSeparator sep1 = new JSeparator();
        sep1.setBounds(10, 60, 670, 10);
        add(sep1);

        table = new JTable(new DefaultTableModel(
                new Object[][]{},
                new String[]{"Blood Group", "Units"}
        ));
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(20, 80, 640, 300);
        add(scrollPane);

        btnClose = new JButton("Close");
        btnClose.setBounds(290, 400, 100, 30);
        add(btnClose);
        btnClose.addActionListener(e -> dispose());

        setVisible(true);
    }

    public static void main(String[] args) {
        new StockDetail();
    }
}
