/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.net.URL;

public class Home extends JFrame {

    public Home() {
        setTitle("Blood Bank Management - Home");
        setSize(1366, 768);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(null);

        // Set background
        URL bgUrl = getClass().getResource("/resources/images/home.png");
        if (bgUrl != null) {
            setContentPane(new JLabel(new ImageIcon(bgUrl)));
        } else {
            System.out.println("Background image not found!");
        }

        // Donor Icon
        JButton donorBtn = createIconButton("/resources/images/Donor.png", 50, 20, "DONOR");
        add(donorBtn);
        donorBtn.addActionListener(e -> showDonorMenu(donorBtn));
        add(createLabel("DONOR", 60, 100));

        // Request Icon
        JButton requestBtn = createIconButton("/resources/images/Blood group.png", 150, 20, "REQUEST");
        add(requestBtn);
        requestBtn.addActionListener(e -> showRequestMenu(requestBtn));
        add(createLabel("REQUEST", 155, 100));

        // Stock Icon
        JButton stockBtn = createIconButton("/resources/images/stock.png", 250, 20, "STOCK");
        add(stockBtn);
        stockBtn.addActionListener(e -> showStockMenu(stockBtn));
        add(createLabel("STOCK", 265, 100));

        // Delete Donor Icon
        JButton deleteBtn = createIconButton("/resources/images/delete donor.png", 350, 20, "DELETE");
        add(deleteBtn);
        deleteBtn.addActionListener(e -> new DeleteDonor().setVisible(true));
        add(createLabel("DELETE", 360, 100));

        // Exit Icon
        JButton exitBtn = createIconButton("/resources/images/exit.png", 450, 20, "EXIT");
        add(exitBtn);
        exitBtn.addActionListener(e -> System.exit(0));
        add(createLabel("EXIT", 470, 100));

        // ➕ Print Icon (new)
        JButton printBtn = createIconButton("/resources/images/print.png", 550, 20, "PRINT");
        add(printBtn);
        printBtn.addActionListener(e -> new PrintAllDetails().setVisible(true));
        add(createLabel("PRINT", 565, 100));

        setVisible(true);
    }

    private JButton createIconButton(String path, int x, int y, String tooltip) {
        URL iconURL = getClass().getResource(path);
        ImageIcon icon = iconURL != null ? new ImageIcon(iconURL) : null;
        JButton button = new JButton(icon);
        button.setBounds(x, y, 80, 80);
        button.setContentAreaFilled(false);
        button.setBorderPainted(false);
        button.setToolTipText(tooltip);
        return button;
    }

    private JLabel createLabel(String text, int x, int y) {
        JLabel label = new JLabel(text);
        label.setBounds(x, y, 100, 20);
        label.setFont(new Font("Arial", Font.BOLD, 14));
        label.setForeground(Color.BLACK);
        return label;
    }

    private void showDonorMenu(Component invoker) {
        JPopupMenu donorMenu = new JPopupMenu();
        JMenuItem addNew = new JMenuItem("Add New Donor");
        JMenuItem allDonor = new JMenuItem("All Donor Details");
        JMenuItem update = new JMenuItem("Update Donor");

        addNew.addActionListener(e -> new AddNewDonor().setVisible(true));
        allDonor.addActionListener(e -> new AllDonorDetail().setVisible(true));
        update.addActionListener(e -> new UpdateDonor().setVisible(true));

        donorMenu.add(addNew);
        donorMenu.add(allDonor);
        donorMenu.add(update);

        donorMenu.show(invoker, invoker.getWidth(), invoker.getHeight());
    }

    private void showRequestMenu(Component invoker) {
        JPopupMenu requestMenu = new JPopupMenu();
        JMenuItem newRequest = new JMenuItem("New Blood Request");
        JMenuItem pendingRequest = new JMenuItem("View Pending Requests");

        newRequest.addActionListener(e -> new NewBloodRequest().setVisible(true));
        pendingRequest.addActionListener(e -> new ViewPendingRequests().setVisible(true));

        requestMenu.add(newRequest);
        requestMenu.add(pendingRequest);

        requestMenu.show(invoker, invoker.getWidth(), invoker.getHeight());
    }

    private void showStockMenu(Component invoker) {
        JPopupMenu stockMenu = new JPopupMenu();
        JMenuItem increase = new JMenuItem("Increase Stock");
        JMenuItem decrease = new JMenuItem("Decrease Stock");
        JMenuItem details = new JMenuItem("Stock Details");

        increase.addActionListener(e -> new StockIncrease().setVisible(true));
        decrease.addActionListener(e -> new StockDecrease().setVisible(true));
        details.addActionListener(e -> new StockDetail().setVisible(true));

        stockMenu.add(increase);
        stockMenu.add(decrease);
        stockMenu.add(details);

        stockMenu.show(invoker, invoker.getWidth(), invoker.getHeight());
    }

    public static void main(String[] args) {
        new Home();
    }
}

