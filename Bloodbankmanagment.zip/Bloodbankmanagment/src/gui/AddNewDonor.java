/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import dao.DonorDao;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;

public class AddNewDonor extends JFrame {

    public JTextField txtDonorId, txtFullName, txtFatherName, txtMotherName, txtContact, txtDOB, txtEmail, txtCity;
    public JComboBox<String> genderCombo, bloodGroupCombo;
    public JTextArea txtAddress;

    public AddNewDonor() {
        setTitle("Add New Donor");
        setSize(700, 520);
        setLocation(360, 130);

        setContentPane(new JLabel(new ImageIcon(getClass().getResource("/resources/images/all page background image.png"))));
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        JLabel title = new JLabel("Add New Donor");
        title.setFont(new Font("Arial", Font.BOLD, 36));
        title.setBounds(200, 10, 400, 40);
        add(title);

        JSeparator separator1 = new JSeparator();
        separator1.setBounds(10, 60, 670, 10);
        add(separator1);

        // Left Column Labels
        JLabel lblDonorId = new JLabel("New Donor ID:");
        JLabel lblFullName = new JLabel("Full Name:");
        JLabel lblFather = new JLabel("Father Name:");
        JLabel lblMother = new JLabel("Mother Name:");
        JLabel lblDOB = new JLabel("Date of Birth:");
        JLabel lblContact = new JLabel("Contact No:");
        JLabel lblGender = new JLabel("Gender:");

        lblDonorId.setBounds(30, 80, 120, 25);
        lblFullName.setBounds(30, 120, 120, 25);
        lblFather.setBounds(30, 160, 120, 25);
        lblMother.setBounds(30, 200, 120, 25);
        lblDOB.setBounds(30, 240, 120, 25);
        lblContact.setBounds(30, 280, 120, 25);
        lblGender.setBounds(30, 320, 120, 25);

        add(lblDonorId); add(lblFullName); add(lblFather);
        add(lblMother); add(lblDOB); add(lblContact); add(lblGender);

        // Left Column Fields
        txtDonorId = new JTextField();
        txtFullName = new JTextField();
        txtFatherName = new JTextField();
        txtMotherName = new JTextField();
        txtDOB = new JTextField("YYYY-MM-DD"); // hint for format
        txtContact = new JTextField();
        genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});

        txtDonorId.setBounds(150, 80, 180, 25);
        txtFullName.setBounds(150, 120, 180, 25);
        txtFatherName.setBounds(150, 160, 180, 25);
        txtMotherName.setBounds(150, 200, 180, 25);
        txtDOB.setBounds(150, 240, 180, 25);
        txtContact.setBounds(150, 280, 180, 25);
        genderCombo.setBounds(150, 320, 180, 25);

        add(txtDonorId); add(txtFullName); add(txtFatherName);
        add(txtMotherName); add(txtDOB); add(txtContact); add(genderCombo);

        // Right Column Labels
        JLabel lblEmail = new JLabel("Email:");
        JLabel lblBloodGroup = new JLabel("Blood Group:");
        JLabel lblCity = new JLabel("City:");
        JLabel lblAddress = new JLabel("Complete Address:");

        lblEmail.setBounds(370, 80, 120, 25);
        lblBloodGroup.setBounds(370, 120, 120, 25);
        lblCity.setBounds(370, 160, 120, 25);
        lblAddress.setBounds(370, 200, 150, 25);

        add(lblEmail); add(lblBloodGroup); add(lblCity); add(lblAddress);

        // Right Column Fields
        txtEmail = new JTextField();
        bloodGroupCombo = new JComboBox<>(new String[]{
                "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"
        });
        txtCity = new JTextField();
        txtAddress = new JTextArea();

        txtEmail.setBounds(500, 80, 150, 25);
        bloodGroupCombo.setBounds(500, 120, 150, 25);
        txtCity.setBounds(500, 160, 150, 25);
        txtAddress.setBounds(500, 200, 150, 60);

        add(txtEmail); add(bloodGroupCombo); add(txtCity); add(txtAddress);

        JSeparator separator2 = new JSeparator();
        separator2.setBounds(10, 370, 670, 10);
        add(separator2);

        JButton btnSave = new JButton("Save");
        JButton btnReset = new JButton("Reset");
        JButton btnClose = new JButton("Close");

        btnSave.setBounds(150, 400, 100, 30);
        btnReset.setBounds(280, 400, 100, 30);
        btnClose.setBounds(410, 400, 100, 30);

        add(btnSave); add(btnReset); add(btnClose);

        btnClose.addActionListener(e -> dispose());
        btnReset.addActionListener(e -> clearFields());

        btnSave.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Map<String, String> donorData = new HashMap<>();
                donorData.put("donorId", txtDonorId.getText());
                donorData.put("fullName", txtFullName.getText());
                donorData.put("fatherName", txtFatherName.getText());
                donorData.put("motherName", txtMotherName.getText());
                donorData.put("DOB", txtDOB.getText()); // ✅ Real DOB value
                donorData.put("mobileNo", txtContact.getText());
                donorData.put("gender", genderCombo.getSelectedItem().toString());
                donorData.put("email", txtEmail.getText());
                donorData.put("bloodGroup", bloodGroupCombo.getSelectedItem().toString());
                donorData.put("city", txtCity.getText());
                donorData.put("address", txtAddress.getText());

                boolean success = DonorDao.addDonor(donorData);
                if (success) {
                    JOptionPane.showMessageDialog(null, "Donor added successfully!");
                    clearFields();
                } else {
                    JOptionPane.showMessageDialog(null, "Error adding donor.");
                }
            }
        });

        setVisible(true);
    }

    private void clearFields() {
        txtDonorId.setText("");
        txtFullName.setText("");
        txtFatherName.setText("");
        txtMotherName.setText("");
        txtDOB.setText("YYYY-MM-DD");
        txtContact.setText("");
        genderCombo.setSelectedIndex(0);
        txtEmail.setText("");
        bloodGroupCombo.setSelectedIndex(0);
        txtCity.setText("");
        txtAddress.setText("");
    }

    public static void main(String[] args) {
        new AddNewDonor();
    }
}

