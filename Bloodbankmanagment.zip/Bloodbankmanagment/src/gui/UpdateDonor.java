/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
 
package gui;
import dao.DonorDao;
import javax.swing.*;
import java.awt.*;
import java.net.URL;

public class UpdateDonor extends JFrame {

    public JTextField txtDonorId, txtFullName, txtFatherName, txtMotherName, txtContact, txtEmail, txtCity;
    public JComboBox<String> genderCombo, bloodGroupCombo;
    public JTextArea txtAddress;
    public JButton btnSearch, btnUpdate, btnReset, btnClose;

    public UpdateDonor() {
        setTitle("Update Donor Details");
        setSize(700, 500);
        setLocation(360, 130);
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Background
        URL imageUrl = getClass().getResource("/resources/images/all page background image.png");
        if (imageUrl != null) {
            setContentPane(new JLabel(new ImageIcon(imageUrl)));
        } else {
            System.out.println("UpdateDonor background image not found.");
        }

        // Title
        JLabel title = new JLabel("Update Donor");
        title.setFont(new Font("Arial", Font.BOLD, 36));
        title.setBounds(200, 10, 400, 40);
        add(title);

        // Separator 1
        JSeparator separator1 = new JSeparator();
        separator1.setBounds(10, 60, 670, 10);
        add(separator1);

        // Donor ID search
        JLabel lblSearchId = new JLabel("Donor ID:");
        lblSearchId.setBounds(30, 70, 100, 25);
        add(lblSearchId);

        txtDonorId = new JTextField();
        txtDonorId.setBounds(150, 70, 180, 25);
        add(txtDonorId);

        btnSearch = new JButton("Search");
        btnSearch.setBounds(350, 70, 100, 25);
        add(btnSearch);

        // Separator 2
        JSeparator separator2 = new JSeparator();
        separator2.setBounds(10, 110, 670, 10);
        add(separator2);

        // Left Column Labels
        JLabel lblFullName = new JLabel("Full Name:");
        JLabel lblFather = new JLabel("Father Name:");
        JLabel lblMother = new JLabel("Mother Name:");
        JLabel lblContact = new JLabel("Contact No:");
        JLabel lblGender = new JLabel("Gender:");

        lblFullName.setBounds(30, 130, 120, 25);
        lblFather.setBounds(30, 170, 120, 25);
        lblMother.setBounds(30, 210, 120, 25);
        lblContact.setBounds(30, 250, 120, 25);
        lblGender.setBounds(30, 290, 120, 25);

        add(lblFullName); add(lblFather); add(lblMother);
        add(lblContact); add(lblGender);

        // Left Column Fields
        txtFullName = new JTextField();
        txtFatherName = new JTextField();
        txtMotherName = new JTextField();
        txtContact = new JTextField();
        genderCombo = new JComboBox<>(new String[]{"Male", "Female", "Other"});

        txtFullName.setBounds(150, 130, 180, 25);
        txtFatherName.setBounds(150, 170, 180, 25);
        txtMotherName.setBounds(150, 210, 180, 25);
        txtContact.setBounds(150, 250, 180, 25);
        genderCombo.setBounds(150, 290, 180, 25);

        add(txtFullName); add(txtFatherName); add(txtMotherName);
        add(txtContact); add(genderCombo);

        // Right Column Labels
        JLabel lblEmail = new JLabel("Email:");
        JLabel lblBloodGroup = new JLabel("Blood Group:");
        JLabel lblCity = new JLabel("City:");
        JLabel lblAddress = new JLabel("Complete Address:");

        lblEmail.setBounds(370, 130, 120, 25);
        lblBloodGroup.setBounds(370, 170, 120, 25);
        lblCity.setBounds(370, 210, 120, 25);
        lblAddress.setBounds(370, 250, 150, 25);

        add(lblEmail); add(lblBloodGroup); add(lblCity); add(lblAddress);

        // Right Column Fields
        txtEmail = new JTextField();
        bloodGroupCombo = new JComboBox<>(new String[]{
            "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"
        });
        txtCity = new JTextField();
        txtAddress = new JTextArea();
        txtAddress.setLineWrap(true);

        txtEmail.setBounds(500, 130, 150, 25);
        bloodGroupCombo.setBounds(500, 170, 150, 25);
        txtCity.setBounds(500, 210, 150, 25);
        txtAddress.setBounds(500, 250, 150, 60);

        add(txtEmail); add(bloodGroupCombo); add(txtCity); add(txtAddress);

        // Separator 3
        JSeparator separator3 = new JSeparator();
        separator3.setBounds(10, 330, 670, 10);
        add(separator3);

        // Buttons
        btnUpdate = new JButton("Update");
        btnReset = new JButton("Reset");
        btnClose = new JButton("Close");

        btnUpdate.setBounds(150, 360, 100, 30);
        btnReset.setBounds(280, 360, 100, 30);
        btnClose.setBounds(410, 360, 100, 30);

        add(btnUpdate); add(btnReset); add(btnClose);

        // Actions
        btnClose.addActionListener(e -> dispose());
        btnReset.addActionListener(e -> clearFields());

        setVisible(true);
    }

    private void clearFields() {
        txtFullName.setText("");
        txtFatherName.setText("");
        txtMotherName.setText("");
        txtContact.setText("");
        genderCombo.setSelectedIndex(0);
        txtEmail.setText("");
        bloodGroupCombo.setSelectedIndex(0);
        txtCity.setText("");
        txtAddress.setText("");
    }

    public static void main(String[] args) {
        new UpdateDonor();
    }
}

