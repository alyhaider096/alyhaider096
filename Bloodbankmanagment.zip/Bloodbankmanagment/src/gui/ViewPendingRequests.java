/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import dao.RequestDao;
import db.ConnectionProvider;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;

public class ViewPendingRequests extends JFrame {

    JTable table;
    DefaultTableModel tableModel;

    public ViewPendingRequests() {
        setTitle("Pending Blood Requests");
        setSize(700, 500);
        setLocation(360, 130);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        // Background
        setContentPane(new JLabel(new ImageIcon(getClass().getResource("/resources/images/all page background image.png"))));

        // Title
        JLabel title = new JLabel("Pending Blood Requests");
        title.setFont(new Font("Arial", Font.BOLD, 30));
        title.setBounds(150, 10, 500, 40);
        add(title);

        // Separator
        JSeparator separator = new JSeparator();
        separator.setBounds(10, 60, 670, 10);
        add(separator);

        // Table Setup
        String[] columns = {"Request ID", "Patient Name", "Blood Group", "Units", "Hospital", "Doctor", "Contact"};
        tableModel = new DefaultTableModel(columns, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(30, 90, 630, 300);
        add(scrollPane);

        // Close Button
        JButton btnClose = new JButton("Close");
        btnClose.setBounds(300, 400, 100, 30);
        add(btnClose);
        btnClose.addActionListener(e -> dispose());

        // Load Data
        loadPendingRequests();

        setVisible(true);
    }

    private void loadPendingRequests() {
        try {
            Connection con = ConnectionProvider.getCon();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM bloodrequest WHERE status = 'Pending'");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Object[] row = {
                        rs.getInt("requestid"),
                        rs.getString("patientName"),
                        rs.getString("bloodGroup"),
                        rs.getInt("unitsRequired"),
                        rs.getString("hospital"),
                        rs.getString("doctorName"),
                        rs.getString("contactNumber")
                };
                tableModel.addRow(row);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading requests: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        new ViewPendingRequests();
    }
}
