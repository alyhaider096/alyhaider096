/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import dao.DonorDao;

import javax.swing.*;
import java.awt.*;

public class DeleteDonor extends JFrame {

    private JTextField txtDonorId;

    public DeleteDonor() {
        setTitle("Delete Donor");
        setSize(700, 500);
        setLocation(360, 130);

        // Background image
        setContentPane(new JLabel(new ImageIcon(getClass().getResource("/resources/images/all page background image.png"))));
        setLayout(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

        // Title
        JLabel title = new JLabel("Delete Donor");
        title.setFont(new Font("Arial", Font.BOLD, 36));
        title.setBounds(220, 10, 400, 40);
        add(title);

        // Separator top
        JSeparator separator1 = new JSeparator();
        separator1.setBounds(10, 60, 670, 10);
        add(separator1);

        // Donor ID label and input
        JLabel lblDonorId = new JLabel("Donor ID:");
        lblDonorId.setFont(new Font("Arial", Font.PLAIN, 18));
        lblDonorId.setBounds(200, 120, 100, 30);
        add(lblDonorId);

        txtDonorId = new JTextField();
        txtDonorId.setBounds(310, 120, 180, 30);
        add(txtDonorId);

        // Separator bottom
        JSeparator separator2 = new JSeparator();
        separator2.setBounds(10, 200, 670, 10);
        add(separator2);

        // Buttons
        JButton btnDelete = new JButton("Delete");
        JButton btnReset = new JButton("Reset");
        JButton btnClose = new JButton("Close");

        btnDelete.setBounds(150, 250, 100, 30);
        btnReset.setBounds(280, 250, 100, 30);
        btnClose.setBounds(410, 250, 100, 30);

        add(btnDelete);
        add(btnReset);
        add(btnClose);

        // Button Actions
        btnClose.addActionListener(e -> dispose());
        btnReset.addActionListener(e -> txtDonorId.setText(""));

        btnDelete.addActionListener(e -> {
            String donorIdStr = txtDonorId.getText().trim();

            if (donorIdStr.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please enter a Donor ID.", "Input Error", JOptionPane.ERROR_MESSAGE);
                return;
            }

            try {
                int donorId = Integer.parseInt(donorIdStr);

                int confirm = JOptionPane.showConfirmDialog(this,
                        "Are you sure you want to delete Donor ID " + donorId + "?",
                        "Confirm Deletion", JOptionPane.YES_NO_OPTION);

                if (confirm == JOptionPane.YES_OPTION) {
                    boolean deleted = DonorDao.deleteDonor(donorId);
                    if (deleted) {
                        JOptionPane.showMessageDialog(this, "Donor deleted successfully.");
                        txtDonorId.setText("");
                    } else {
                        JOptionPane.showMessageDialog(this, "Donor ID not found or deletion failed.",
                                "Error", JOptionPane.ERROR_MESSAGE);
                    }
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(this, "Donor ID must be a valid number.",
                        "Input Error", JOptionPane.ERROR_MESSAGE);
            } catch (Exception ex) {
                ex.printStackTrace();
                JOptionPane.showMessageDialog(this, "Error deleting donor: " + ex.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new DeleteDonor();
    }
}
