/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import dao.DonorDao;
import dao.StockDao;
import dao.RequestDao;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.net.URL;
import java.sql.ResultSet;
import java.sql.SQLException;

public class PrintAllDetails extends JFrame {

    public PrintAllDetails() {
        setTitle("All Details — Donors · Stock · Requests");
        setSize(900, 700);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        // Optional background image
        URL bgUrl = getClass().getResource("/resources/images/login background final.png");
        if (bgUrl != null) {
            setContentPane(new JLabel(new ImageIcon(bgUrl)));
        }

        // Title label
        JLabel title = new JLabel("All Details Overview");
        title.setFont(new Font("Arial", Font.BOLD, 32));
        title.setBounds(260, 10, 400, 40);
        add(title);

        int y = 60;

        // Donor table
        String[] dCols = {"ID", "Name", "Mobile", "B.Group", "City", "Gender", "Email"};
        DefaultTableModel modelDonor = new DefaultTableModel(dCols, 0);
        JTable tblDonor = new JTable(modelDonor);
        JScrollPane ds = new JScrollPane(tblDonor);
        ds.setBounds(20, y + 30, 840, 120);
        add(ds);
        loadDonorData(modelDonor);
        y += 160;

        // Stock table
        String[] sCols = {"Blood Group", "Units"};
        DefaultTableModel modelStock = new DefaultTableModel(sCols, 0);
        JTable tblStock = new JTable(modelStock);
        JScrollPane ss = new JScrollPane(tblStock);
        ss.setBounds(20, y + 30, 840, 100);
        add(ss);
        loadStockData(modelStock);
        y += 140;

        // Request table
        String[] rCols = {"ID", "Patient", "B.Group", "Units", "Hospital", "Status"};
        DefaultTableModel modelRequest = new DefaultTableModel(rCols, 0);
        JTable tblRequest = new JTable(modelRequest);
        JScrollPane rs = new JScrollPane(tblRequest);
        rs.setBounds(20, y + 30, 840, 120);
        add(rs);
        loadRequestData(modelRequest);

        // Buttons panel
        JPanel bp = new JPanel(new FlowLayout(FlowLayout.CENTER));
        bp.setBounds(300, 600, 300, 40);
        bp.setOpaque(false);

        JButton btnPrint = new JButton("Print");
        btnPrint.addActionListener(e -> {
            try {
                tblDonor.print();
                tblStock.print();
                tblRequest.print();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error printing: " + ex.getMessage());
            }
        });
        bp.add(btnPrint);

        JButton btnClose = new JButton("Close");
        btnClose.addActionListener(e -> dispose());
        bp.add(btnClose);

        add(bp);

        setVisible(true);
    }

    private void loadDonorData(DefaultTableModel model) {
        try (ResultSet rs = DonorDao.getAllDonors()) {
            if (rs != null) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getInt("donorid"),
                        rs.getString("fullName"),
                        rs.getString("mobileNo"),
                        rs.getString("bloodGroup"),
                        rs.getString("city"),
                        rs.getString("gender"),
                        rs.getString("email")
                    });
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading donor data.");
        }
    }

    private void loadStockData(DefaultTableModel model) {
        try (ResultSet rs = StockDao.getStockDetails()) {
            if (rs != null) {
                while (rs.next()) {
                    model.addRow(new Object[]{
                        rs.getString("bloodGroup"),
                        rs.getInt("units")
                    });
                }
            }
        } catch (SQLException e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Error loading stock data.");
        }
    }

   private void loadRequestData(DefaultTableModel model) {
    try (ResultSet rs = RequestDao.getAllRequests()) {
        if (rs != null) {
            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("requestid"),
                    rs.getString("patientName"),
                    rs.getString("bloodGroup"),
                    rs.getInt("unitsRequired"),
                    rs.getString("hospital"),
                    rs.getString("status")
                });
            }
        }
    } catch (SQLException e) {
        e.printStackTrace();
        JOptionPane.showMessageDialog(this, "Error loading request data.");
    }
}

    public static void main(String[] args) {
        new PrintAllDetails();
    }
}
