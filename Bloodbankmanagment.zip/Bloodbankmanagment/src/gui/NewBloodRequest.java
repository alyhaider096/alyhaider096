/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package gui;

import dao.RequestDao;
import javax.swing.*;
import java.awt.*;

public class NewBloodRequest extends JFrame {

    public NewBloodRequest() {
        setTitle("New Blood Request");
        setSize(700, 500);
        setLocation(360, 130);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        // Background image
        setContentPane(new JLabel(new ImageIcon(getClass().getResource("/resources/images/all page background image.png"))));

        // Title
        JLabel title = new JLabel("New Blood Request");
        title.setFont(new Font("Arial", Font.BOLD, 36));
        title.setBounds(150, 10, 500, 40);
        add(title);

        // Separator
        JSeparator separator = new JSeparator();
        separator.setBounds(10, 60, 670, 10);
        add(separator);

        // Labels and fields
        JLabel lblPatientName = new JLabel("Patient Name:");
        JLabel lblBloodGroup = new JLabel("Blood Group:");
        JLabel lblUnits = new JLabel("Units Required:");
        JLabel lblHospital = new JLabel("Hospital:");
        JLabel lblDoctor = new JLabel("Doctor Name:");
        JLabel lblContact = new JLabel("Contact Number:");

        JTextField txtPatientName = new JTextField();
        JComboBox<String> cbBloodGroup = new JComboBox<>(new String[]{
            "A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-"
        });
        JTextField txtUnits = new JTextField();
        JTextField txtHospital = new JTextField();
        JTextField txtDoctor = new JTextField();
        JTextField txtContact = new JTextField();

        int xLabel = 50, xField = 200, y = 100, h = 25, spacing = 40;

        lblPatientName.setBounds(xLabel, y, 120, h);
        txtPatientName.setBounds(xField, y, 400, h); y += spacing;

        lblBloodGroup.setBounds(xLabel, y, 120, h);
        cbBloodGroup.setBounds(xField, y, 400, h); y += spacing;

        lblUnits.setBounds(xLabel, y, 120, h);
        txtUnits.setBounds(xField, y, 400, h); y += spacing;

        lblHospital.setBounds(xLabel, y, 120, h);
        txtHospital.setBounds(xField, y, 400, h); y += spacing;

        lblDoctor.setBounds(xLabel, y, 120, h);
        txtDoctor.setBounds(xField, y, 400, h); y += spacing;

        lblContact.setBounds(xLabel, y, 120, h);
        txtContact.setBounds(xField, y, 400, h);

        add(lblPatientName); add(txtPatientName);
        add(lblBloodGroup); add(cbBloodGroup);
        add(lblUnits); add(txtUnits);
        add(lblHospital); add(txtHospital);
        add(lblDoctor); add(txtDoctor);
        add(lblContact); add(txtContact);

        // Buttons
        JButton btnSubmit = new JButton("Submit");
        JButton btnClear = new JButton("Clear");
        JButton btnClose = new JButton("Close");

        btnSubmit.setBounds(150, 380, 100, 30);
        btnClear.setBounds(280, 380, 100, 30);
        btnClose.setBounds(410, 380, 100, 30);

        add(btnSubmit); add(btnClear); add(btnClose);

        // Actions
        btnClose.addActionListener(e -> dispose());

        btnClear.addActionListener(e -> {
            txtPatientName.setText("");
            cbBloodGroup.setSelectedIndex(0);
            txtUnits.setText("");
            txtHospital.setText("");
            txtDoctor.setText("");
            txtContact.setText("");
        });

        btnSubmit.addActionListener(e -> {
            String name = txtPatientName.getText().trim();
            String group = cbBloodGroup.getSelectedItem().toString();
            String units = txtUnits.getText().trim();
            String hospital = txtHospital.getText().trim();
            String doctor = txtDoctor.getText().trim();
            String contact = txtContact.getText().trim();

            if (name.isEmpty() || units.isEmpty() || hospital.isEmpty() || doctor.isEmpty() || contact.isEmpty()) {
                JOptionPane.showMessageDialog(null, "Please fill all fields.");
                return;
            }

            try {
                int unitCount = Integer.parseInt(units);
                long phone = Long.parseLong(contact);

                boolean result = RequestDao.saveRequest(name, group, unitCount, hospital, doctor, contact);
                if (result) {
                    JOptionPane.showMessageDialog(null, "Blood request submitted successfully.");
                    btnClear.doClick(); // clear form
                } else {
                    JOptionPane.showMessageDialog(null, "Failed to submit blood request.");
                }

            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(null, "Units and contact must be numbers.");
            }
        });

        setVisible(true);
    }

    public static void main(String[] args) {
        new NewBloodRequest();
    }
}
